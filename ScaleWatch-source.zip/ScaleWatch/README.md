# ScaleWatch (MVP)

A Waze-style app for truck drivers: shows weigh/inspection stations on an
OpenStreetMap map, lets drivers report station status and police/inspection
activity, and expires old reports automatically.

## How the APK gets built

This project has no local build step required. It includes a GitHub Actions
workflow (`.github/workflows/build-apk.yml`) that compiles the app into an
installable APK automatically, for free, every time the code is pushed to
GitHub. See BUILD_INSTRUCTIONS.md for exact phone steps.

## Project layout

- `app/src/main/java/com/scalewatch/app/`
  - `Station.kt`, `Report.kt` — data models
  - `StationRepository.kt` — loads stations (currently from `assets/stations.json`;
    swap this for a bigger file or a real database later without touching
    anything else)
  - `ReportRepository.kt` — stores driver reports on-device and expires them
  - `MainActivity.kt` — map, GPS, markers, report dialogs, info panel
- `app/src/main/assets/stations.json` — sample station dataset (5 stations
  near the I-40/I-55 Memphis interchange, for immediate testing)
- `app/src/main/res/` — layouts, colors (light + dark), icons

## Extending later

- Nationwide stations: replace/expand `stations.json`, or point
  `StationRepository.loadStations()` at a bundled SQLite file or remote API.
- Shared reports between drivers: swap `ReportRepository`'s local
  SharedPreferences storage for a backend call — its public methods
  (`addReport`, `getActiveReports`, `statusFor`) can stay the same.
- Accounts, push notifications, route alerts, voting: none of these are
  built yet, but the data models were kept simple on purpose so they're easy
  to extend.
