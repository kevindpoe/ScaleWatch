package com.scalewatch.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import com.scalewatch.app.databinding.ActivityMainBinding
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var stationRepo: StationRepository
    private lateinit var reportRepo: ReportRepository
    private lateinit var myLocationOverlay: MyLocationNewOverlay

    private var stations: List<Station> = emptyList()
    private val stationMarkers = mutableMapOf<String, Marker>()
    private var selectedStation: Station? = null

    private val locationPermissionRequest = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            enableMyLocation()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // osmdroid needs its config loaded (and a user agent set) before any map view is created.
        Configuration.getInstance().load(
            applicationContext,
            getSharedPreferences("osmdroid_prefs", MODE_PRIVATE)
        )
        Configuration.getInstance().userAgentValue = packageName

        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        stationRepo = StationRepository(this)
        reportRepo = ReportRepository(this)
        stations = stationRepo.loadStations()

        setupMap()
        setupReportMarkers()
        refreshStationMarkers()
        requestLocationPermissionIfNeeded()

        binding.fabLocate.setOnClickListener { centerOnMyLocation() }
        binding.fabReport.setOnClickListener { showGeneralReportDialog() }
        binding.btnClosePanel.setOnClickListener { hideStationPanel() }
        binding.btnMarkOpen.setOnClickListener { submitStationReport(ReportType.STATION_OPEN) }
        binding.btnMarkClosed.setOnClickListener { submitStationReport(ReportType.STATION_CLOSED) }
    }

    private fun setupMap() {
        val map = binding.mapView
        map.setTileSource(TileSourceFactory.MAPNIK) // OpenStreetMap tiles — free, no API key
        map.setMultiTouchControls(true)
        map.controller.setZoom(9.5)

        val defaultCenter = if (stations.isNotEmpty()) {
            GeoPoint(stations[0].lat, stations[0].lon)
        } else {
            GeoPoint(35.1, -90.05)
        }
        map.controller.setCenter(defaultCenter)

        myLocationOverlay = MyLocationNewOverlay(GpsMyLocationProvider(this), map)
        map.overlays.add(myLocationOverlay)
    }

    private fun requestLocationPermissionIfNeeded() {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (fine == PackageManager.PERMISSION_GRANTED || coarse == PackageManager.PERMISSION_GRANTED) {
            enableMyLocation()
        } else {
            locationPermissionRequest.launch(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            )
        }
    }

    private fun enableMyLocation() {
        myLocationOverlay.enableMyLocation()
        myLocationOverlay.enableFollowLocation()
        binding.mapView.invalidate()
    }

    private fun centerOnMyLocation() {
        val point = myLocationOverlay.myLocation
        if (point != null) {
            binding.mapView.controller.animateTo(point)
            binding.mapView.controller.setZoom(13.0)
        }
    }

    // ---------- Station markers ----------

    private fun refreshStationMarkers() {
        val map = binding.mapView
        for (station in stations) {
            val (status, _) = reportRepo.statusFor(station.id)
            val existing = stationMarkers[station.id]
            if (existing != null) {
                existing.icon = iconFor(status)
                continue
            }
            val marker = Marker(map).apply {
                position = GeoPoint(station.lat, station.lon)
                setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                icon = iconFor(status)
                title = station.name
                setOnMarkerClickListener { _, _ ->
                    showStationPanel(station)
                    true
                }
            }
            map.overlays.add(marker)
            stationMarkers[station.id] = marker
        }
        map.invalidate()
    }

    private fun iconFor(status: StationStatus): Drawable? {
        val res = when (status) {
            StationStatus.OPEN -> R.drawable.marker_open
            StationStatus.CLOSED -> R.drawable.marker_closed
            StationStatus.UNKNOWN -> R.drawable.marker_unknown
        }
        return ResourcesCompat.getDrawable(resources, res, theme)
    }

    // ---------- Report markers (police / inspection / other, plotted on map) ----------

    private fun setupReportMarkers() {
        val map = binding.mapView
        for (report in reportRepo.getActiveReports()) {
            if (report.type == ReportType.INSPECTION_ACTIVITY || report.type == ReportType.POLICE_ACTIVITY || report.type == ReportType.OTHER) {
                addReportMarker(report)
            }
        }
        map.invalidate()
    }

    private fun addReportMarker(report: Report) {
        val map = binding.mapView
        val iconRes = if (report.type == ReportType.POLICE_ACTIVITY) R.drawable.marker_police else R.drawable.marker_report
        val marker = Marker(map).apply {
            position = GeoPoint(report.lat, report.lon)
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            icon = ResourcesCompat.getDrawable(resources, iconRes, theme)
            title = labelFor(report.type)
            snippet = timeAgo(report.timestamp) + (report.note?.let { " — $it" } ?: "")
        }
        map.overlays.add(marker)
    }

    // ---------- Station info panel ----------

    private fun showStationPanel(station: Station) {
        selectedStation = station
        val (status, lastReport) = reportRepo.statusFor(station.id)

        binding.panelTitle.text = station.name
        binding.panelSubtitle.text = if (station.type == StationType.WEIGH) "Weigh Station" else "Inspection Station"

        val statusLabel = when (status) {
            StationStatus.OPEN -> getString(R.string.status_open)
            StationStatus.CLOSED -> getString(R.string.status_closed)
            StationStatus.UNKNOWN -> getString(R.string.status_unknown)
        }
        val statusColor = when (status) {
            StationStatus.OPEN -> R.color.status_open
            StationStatus.CLOSED -> R.color.status_closed
            StationStatus.UNKNOWN -> R.color.status_unknown
        }
        binding.panelStatus.setTextColor(ContextCompat.getColor(this, statusColor))
        binding.panelStatus.text = if (lastReport != null) {
            "Status: $statusLabel — reported ${timeAgo(lastReport.timestamp)}"
        } else {
            "Status: $statusLabel — no recent reports"
        }

        binding.stationPanel.visibility = View.VISIBLE
    }

    private fun hideStationPanel() {
        selectedStation = null
        binding.stationPanel.visibility = View.GONE
    }

    private fun submitStationReport(type: ReportType) {
        val station = selectedStation ?: return
        val loc = myLocationOverlay.myLocation
        val lat = loc?.latitude ?: station.lat
        val lon = loc?.longitude ?: station.lon

        reportRepo.addReport(type = type, lat = lat, lon = lon, stationId = station.id)
        refreshStationMarkers()
        showStationPanel(station) // refresh panel text with new status
    }

    // ---------- General "Report Activity" (police / inspection / other) ----------

    private fun showGeneralReportDialog() {
        val options = arrayOf("Police activity", "Inspection activity", "Other")
        val types = arrayOf(ReportType.POLICE_ACTIVITY, ReportType.INSPECTION_ACTIVITY, ReportType.OTHER)

        AlertDialog.Builder(this)
            .setTitle("What are you reporting?")
            .setItems(options) { _, which ->
                promptForOptionalNote(types[which])
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun promptForOptionalNote(type: ReportType) {
        val input = EditText(this).apply {
            hint = "Optional note (e.g. \"northbound shoulder, mile 42\")"
            inputType = InputType.TYPE_CLASS_TEXT
        }
        AlertDialog.Builder(this)
            .setTitle("Add a note? (optional)")
            .setView(input)
            .setPositiveButton("Submit") { _, _ ->
                submitGeneralReport(type, input.text?.toString()?.trim().takeUnless { it.isNullOrEmpty() })
            }
            .setNegativeButton("Skip") { _, _ ->
                submitGeneralReport(type, null)
            }
            .show()
    }

    private fun submitGeneralReport(type: ReportType, note: String?) {
        val loc = myLocationOverlay.myLocation
        if (loc == null) {
            AlertDialog.Builder(this)
                .setTitle("Location not available yet")
                .setMessage("Waiting for GPS. Make sure location is enabled, then try again in a moment.")
                .setPositiveButton("OK", null)
                .show()
            return
        }
        val report = reportRepo.addReport(type = type, lat = loc.latitude, lon = loc.longitude, note = note)
        addReportMarker(report)
        binding.mapView.invalidate()
    }

    // ---------- Helpers ----------

    private fun labelFor(type: ReportType): String = when (type) {
        ReportType.STATION_OPEN -> "Station reported OPEN"
        ReportType.STATION_CLOSED -> "Station reported CLOSED"
        ReportType.INSPECTION_ACTIVITY -> "Inspection activity"
        ReportType.POLICE_ACTIVITY -> "Police activity"
        ReportType.OTHER -> "Report"
    }

    private fun timeAgo(timestamp: Long): String {
        val diff = System.currentTimeMillis() - timestamp
        val minutes = TimeUnit.MILLISECONDS.toMinutes(diff)
        return when {
            minutes < 1 -> "just now"
            minutes < 60 -> "$minutes min ago"
            else -> {
                val hours = TimeUnit.MILLISECONDS.toHours(diff)
                if (hours < 24) "$hours hr ago" else SimpleDateFormat("MMM d, h:mm a", Locale.US).format(Date(timestamp))
            }
        }
    }

    override fun onResume() {
        super.onResume()
        binding.mapView.onResume()
        refreshStationMarkers()
    }

    override fun onPause() {
        super.onPause()
        binding.mapView.onPause()
    }
}
