package com.scalewatch.app

import android.content.Context
import org.json.JSONObject

/**
 * Loads stations from assets/stations.json.
 *
 * To grow this into a nationwide database later, the simplest path is:
 *   1. Replace stations.json with a bigger file (or split by state), OR
 *   2. Swap loadStations() to read from a bundled SQLite file / Room database
 *      / remote API instead of assets.
 * Nothing else in the app needs to change, since everything else only
 * depends on the Station data class and this repository's public method.
 */
class StationRepository(private val context: Context) {

    fun loadStations(): List<Station> {
        val json = context.assets.open("stations.json").bufferedReader().use { it.readText() }
        val root = JSONObject(json)
        val arr = root.getJSONArray("stations")
        val result = mutableListOf<Station>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            result.add(
                Station(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    type = StationType.valueOf(o.getString("type")),
                    lat = o.getDouble("lat"),
                    lon = o.getDouble("lon")
                )
            )
        }
        return result
    }
}
