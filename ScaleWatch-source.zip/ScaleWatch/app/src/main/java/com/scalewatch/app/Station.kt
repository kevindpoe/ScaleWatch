package com.scalewatch.app

/**
 * A weigh station or inspection station.
 *
 * This is intentionally minimal for the MVP. When a nationwide database is
 * added later, it can be dropped in as a bigger JSON file (or swapped for a
 * SQLite/Room-backed source) without changing any code that consumes
 * StationRepository — only loadStations() needs to change.
 */
data class Station(
    val id: String,
    val name: String,
    val type: StationType,
    val lat: Double,
    val lon: Double
)

enum class StationType {
    WEIGH,
    INSPECTION
}

enum class StationStatus {
    OPEN,
    CLOSED,
    UNKNOWN
}
