package com.scalewatch.app

/**
 * A driver-submitted report. Every report is tied to a location and time,
 * and expires automatically (see ReportRepository.EXPIRY_MILLIS_BY_TYPE).
 *
 * stationId is set when the report is about a specific station (open/closed).
 * It is null for general road reports (police / inspection activity / other)
 * that aren't tied to one of the known stations.
 */
data class Report(
    val id: String,
    val type: ReportType,
    val stationId: String?,
    val lat: Double,
    val lon: Double,
    val timestamp: Long,
    val note: String? = null
)

enum class ReportType {
    STATION_OPEN,
    STATION_CLOSED,
    INSPECTION_ACTIVITY,
    POLICE_ACTIVITY,
    OTHER
}
