package com.scalewatch.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Stores reports on-device (SharedPreferences, as a JSON array) so the MVP
 * needs no server or account system. Expired reports are dropped every time
 * the list is read or written.
 *
 * When a backend is added later (for sharing reports between drivers), this
 * class's public interface (addReport / getActiveReports / statusFor) can
 * stay the same while the implementation switches to network calls.
 */
class ReportRepository(context: Context) {

    private val prefs = context.getSharedPreferences("scalewatch_reports", Context.MODE_PRIVATE)

    companion object {
        private const val KEY = "reports_json"

        // How long each report type stays "active" before it's treated as stale.
        val EXPIRY_MILLIS_BY_TYPE: Map<ReportType, Long> = mapOf(
            ReportType.STATION_OPEN to 4 * 60 * 60 * 1000L,       // 4 hours
            ReportType.STATION_CLOSED to 4 * 60 * 60 * 1000L,     // 4 hours
            ReportType.INSPECTION_ACTIVITY to 2 * 60 * 60 * 1000L, // 2 hours
            ReportType.POLICE_ACTIVITY to 90 * 60 * 1000L,         // 90 minutes
            ReportType.OTHER to 2 * 60 * 60 * 1000L
        )
    }

    fun addReport(
        type: ReportType,
        lat: Double,
        lon: Double,
        stationId: String? = null,
        note: String? = null
    ): Report {
        val report = Report(
            id = UUID.randomUUID().toString(),
            type = type,
            stationId = stationId,
            lat = lat,
            lon = lon,
            timestamp = System.currentTimeMillis(),
            note = note
        )
        val all = readAll().toMutableList()
        all.add(report)
        writeAll(all)
        return report
    }

    /** All non-expired reports, newest first. */
    fun getActiveReports(): List<Report> {
        val now = System.currentTimeMillis()
        val active = readAll().filter { !isExpired(it, now) }
        // Persist the cleaned-up list so storage doesn't grow forever.
        writeAll(active)
        return active.sortedByDescending { it.timestamp }
    }

    /** Derives a station's current status from the most recent active report about it. */
    fun statusFor(stationId: String): Pair<StationStatus, Report?> {
        val relevant = getActiveReports()
            .filter { it.stationId == stationId && (it.type == ReportType.STATION_OPEN || it.type == ReportType.STATION_CLOSED) }
            .maxByOrNull { it.timestamp }
            ?: return StationStatus.UNKNOWN to null

        val status = if (relevant.type == ReportType.STATION_OPEN) StationStatus.OPEN else StationStatus.CLOSED
        return status to relevant
    }

    private fun isExpired(report: Report, now: Long): Boolean {
        val expiry = EXPIRY_MILLIS_BY_TYPE[report.type] ?: (4 * 60 * 60 * 1000L)
        return now - report.timestamp > expiry
    }

    private fun readAll(): List<Report> {
        val json = prefs.getString(KEY, null) ?: return emptyList()
        val arr = JSONArray(json)
        val result = mutableListOf<Report>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            result.add(
                Report(
                    id = o.getString("id"),
                    type = ReportType.valueOf(o.getString("type")),
                    stationId = if (o.isNull("stationId")) null else o.getString("stationId"),
                    lat = o.getDouble("lat"),
                    lon = o.getDouble("lon"),
                    timestamp = o.getLong("timestamp"),
                    note = if (o.isNull("note")) null else o.getString("note")
                )
            )
        }
        return result
    }

    private fun writeAll(reports: List<Report>) {
        val arr = JSONArray()
        for (r in reports) {
            val o = JSONObject()
            o.put("id", r.id)
            o.put("type", r.type.name)
            o.put("stationId", r.stationId)
            o.put("lat", r.lat)
            o.put("lon", r.lon)
            o.put("timestamp", r.timestamp)
            o.put("note", r.note)
            arr.put(o)
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }
}
